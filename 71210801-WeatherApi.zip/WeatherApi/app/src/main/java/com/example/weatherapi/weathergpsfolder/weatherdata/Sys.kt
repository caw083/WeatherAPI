package com.example.weatherapi.weathergpsfolder.weatherdata

data class Sys(val pod: String)
