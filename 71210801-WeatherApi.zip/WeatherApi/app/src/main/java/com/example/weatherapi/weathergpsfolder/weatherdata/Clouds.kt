package com.example.weatherapi.weathergpsfolder.weatherdata

data class Clouds(val all: Int)
